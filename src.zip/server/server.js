
'use strict';

const http = require('http');

const application = require('./application');
const httpServer  = http.createServer(application);

const httpPort = process.env.HTTP_PORT || 80;

httpServer.listen(httpPort, () => {
	console.log(`HTTP server is running on port ${httpPort}.`);
});