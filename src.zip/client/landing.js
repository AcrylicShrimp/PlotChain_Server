
const $window     = $(window);
const $document   = $(document);
const $background = $('.background');

$('#about-button').on('click', function() {
	$('html').animate({
		scrollTop: $('#about').offset().top - $('#about').height() / 2
	}, 500);
});

$('#value-button').on('click', function () {
	$('html').animate({
		scrollTop: $('#value').offset().top - $('#value').height() / 2
	}, 500);
});

$('#member-button').on('click', function () {
	$('html').animate({
		scrollTop: $('#member').offset().top - $('#member').height() / 4
	}, 500);
});

$(document).ready(() => {
	$window.scroll(updateBackground);
	$window.resize(updateBackground);
	$('html').css('opacity', 1);

	updateBackground();
});

function updateBackground() {
	$background.css('background-position', `${calcBackgroundHorizontal()}% ${calcBackgroundVertical()}%`);
}

function calcBackgroundHorizontal() {
	const factor = ($document.width() - $window.width());

	if (factor <= 0)
		return 50;

	return $window.scrollLeft() / factor * 100;
}

function calcBackgroundVertical() {
	const factor = ($document.height() - $window.height());

	if (factor <= 0)
		return 50;
	
	return $window.scrollTop() / factor * 100;
}